<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-12 18:15:45 --> Severity: Notice --> Undefined variable: nf /Users/saleem/Sites/sma/app/controllers/admin/System_settings.php 2851
ERROR - 2019-09-12 18:57:44 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:57:44 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:58:23 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:58:23 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:58:23 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:58:23 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:58:23 --> Severity: Notice --> Undefined property: stdClass::$id /Users/saleem/Sites/sma/app/models/Site.php 1272
ERROR - 2019-09-12 18:58:23 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: UPDATE `sma_order_ref` SET `ex` = 1
WHERE `id` IS NULL
ERROR - 2019-09-12 18:58:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/saleem/Sites/sma/system/core/Exceptions.php:271) /Users/saleem/Sites/sma/system/core/Common.php 570
ERROR - 2019-09-12 18:59:14 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:59:14 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:59:14 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:59:14 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:59:14 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:59:14 --> Severity: Warning --> A non-numeric value encountered /Users/saleem/Sites/sma/app/models/Site.php 714
ERROR - 2019-09-12 18:59:14 --> Severity: Notice --> Undefined property: stdClass::$id /Users/saleem/Sites/sma/app/models/Site.php 1272
ERROR - 2019-09-12 18:59:14 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: UPDATE `sma_order_ref` SET `ex` = 1
WHERE `id` IS NULL
ERROR - 2019-09-12 18:59:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/saleem/Sites/sma/system/core/Exceptions.php:271) /Users/saleem/Sites/sma/system/core/Common.php 570
ERROR - 2019-09-12 18:59:32 --> Severity: Notice --> Undefined property: stdClass::$id /Users/saleem/Sites/sma/app/models/Site.php 1272
ERROR - 2019-09-12 18:59:32 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: UPDATE `sma_order_ref` SET `ex` = 1
WHERE `id` IS NULL
ERROR - 2019-09-12 19:00:11 --> Severity: Notice --> Undefined property: stdClass::$id /Users/saleem/Sites/sma/app/models/Site.php 1272
ERROR - 2019-09-12 19:00:33 --> Severity: Notice --> Undefined property: stdClass::$id /Users/saleem/Sites/sma/app/models/Site.php 1272
ERROR - 2019-09-12 19:04:28 --> Severity: Notice --> Undefined property: stdClass::$id /Users/saleem/Sites/sma/app/models/Site.php 1271
ERROR - 2019-09-12 19:11:29 --> Severity: Notice --> Undefined variable: nf /Users/saleem/Sites/sma/app/controllers/admin/System_settings.php 2851
ERROR - 2019-09-12 21:51:58 --> Severity: Notice --> Undefined property: stdClass::$reference_prefix /Users/saleem/Sites/sma/themes/default/admin/views/settings/edit_warehouse.php 16
ERROR - 2019-09-12 21:54:15 --> Query error: Unknown column 'reference_prefix' in 'field list' - Invalid query: UPDATE `sma_order_ref` SET `reference_prefix` = 'Kuchi'
WHERE `warehouse_id` = '1'
ERROR - 2019-09-12 21:56:52 --> Severity: Notice --> Undefined variable: nf /Users/saleem/Sites/sma/app/controllers/admin/System_settings.php 2861
ERROR - 2019-09-12 22:05:22 --> Severity: Notice --> Trying to get property 'warehouse_prefix' of non-object /Users/saleem/Sites/sma/app/controllers/admin/System_settings.php 1507
ERROR - 2019-09-12 22:05:41 --> Severity: Notice --> Trying to get property 'warehouse_prefix' of non-object /Users/saleem/Sites/sma/app/controllers/admin/System_settings.php 1507
