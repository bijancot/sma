<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-30 11:31:45 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:31:46 --> Query error: Table 'sma.sma_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `sma_sessions`
WHERE `id` = 's2gsvpgctv85bokmam09if1m0ur2246u'
ERROR - 2019-07-30 11:31:46 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-07-30 11:31:46 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-07-30 11:31:46 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:31:46 --> Query error: Table 'sma.sma_sessions' doesn't exist - Invalid query: SELECT 1
FROM `sma_sessions`
WHERE `id` = 's2gsvpgctv85bokmam09if1m0ur2246u'
ERROR - 2019-07-30 11:31:46 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-07-30 11:35:04 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:22 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:23 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:23 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:34 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:35:35 --> Query error:  - Invalid query: UPDATE `sma_sessions` SET `timestamp` = 1564457735, `data` = ''
WHERE `id` = ''
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:35:35 --> Query error:  - Invalid query: SELECT RELEASE_LOCK('8eb625877decab2a36420d09b582c1bf') AS ci_session_lock
ERROR - 2019-07-30 11:35:35 --> Severity: Warning --> Cannot modify header information - headers already sent /Users/saleem/Sites/sma/system/core/Common.php 570
ERROR - 2019-07-30 11:35:35 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:35 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:41 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:35:41 --> Query error:  - Invalid query: UPDATE `sma_sessions` SET `timestamp` = 1564457741, `data` = ''
WHERE `id` = ''
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:35:41 --> Query error:  - Invalid query: SELECT RELEASE_LOCK('68dcf40b7f24fd46c581621c5939a7fa') AS ci_session_lock
ERROR - 2019-07-30 11:35:41 --> Severity: Warning --> Cannot modify header information - headers already sent /Users/saleem/Sites/sma/system/core/Common.php 570
ERROR - 2019-07-30 11:35:41 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:35:41 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:44:39 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:44:40 --> Query error:  - Invalid query: INSERT INTO `sma_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('', '', 1564458280, '')
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:44:40 --> Query error:  - Invalid query: SELECT RELEASE_LOCK('4c948c4c832d041039e8a09fef85425c') AS ci_session_lock
ERROR - 2019-07-30 11:44:40 --> Severity: Warning --> Cannot modify header information - headers already sent /Users/saleem/Sites/sma/system/core/Common.php 570
ERROR - 2019-07-30 11:44:40 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:44:41 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:47:12 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:47:12 --> Query error:  - Invalid query: UPDATE `sma_sessions` SET `timestamp` = 1564458432, `data` = ''
WHERE `id` = ''
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 509
ERROR - 2019-07-30 11:47:12 --> Query error:  - Invalid query: SELECT RELEASE_LOCK('91c952c851b5ab4b63360abbb658f51a') AS ci_session_lock
ERROR - 2019-07-30 11:47:12 --> Severity: Warning --> Cannot modify header information - headers already sent /Users/saleem/Sites/sma/system/core/Common.php 570
ERROR - 2019-07-30 11:47:13 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:47:13 --> Could not find the specified $config['composer_autoload'] path: /Users/saleem/Sites/sma/vendor/autoload.php
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 511
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 511
ERROR - 2019-07-30 11:58:57 --> Query error:  - Invalid query: INSERT INTO `sma_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('', '', 1564459137, '')
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 511
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 511
ERROR - 2019-07-30 11:58:57 --> Query error:  - Invalid query: SELECT RELEASE_LOCK('bd344d52610c4ab203acd318b98c7920') AS ci_session_lock
ERROR - 2019-07-30 11:58:57 --> Severity: Warning --> Cannot modify header information - headers already sent /Users/saleem/Sites/sma/system/core/Common.php 570
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> mysqli::real_escape_string(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 511
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 511
ERROR - 2019-07-30 12:01:25 --> Query error:  - Invalid query: UPDATE `sma_sessions` SET `timestamp` = 1564459285, `data` = ''
WHERE `id` = ''
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> mysqli::query(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 511
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> CI_DB_mysqli_driver::error(): Couldn't fetch mysqli /Users/saleem/Sites/sma/system/database/drivers/mysqli/mysqli_driver.php 511
ERROR - 2019-07-30 12:01:25 --> Query error:  - Invalid query: SELECT RELEASE_LOCK('bd344d52610c4ab203acd318b98c7920') AS ci_session_lock
ERROR - 2019-07-30 12:01:25 --> Severity: Warning --> Cannot modify header information - headers already sent /Users/saleem/Sites/sma/system/core/Common.php 570
ERROR - 2019-07-30 12:08:48 --> Severity: Notice --> Undefined property: stdClass::$special_price /Users/saleem/Sites/sma/app/controllers/shop/Shop.php 223
ERROR - 2019-07-30 12:08:49 --> Could not find the language line "new_sale"
ERROR - 2019-07-30 17:26:34 --> Why else: Array
(
    [product_id] => 23
    [option_id] => 
    [warehouse_id] => 1
    [status] => received
    [product_unit_id] => 4
    [product_unit_code] => pc
    [product_code] => T111
    [product_name] => Test Case 1
    [item_tax] => 0.00
    [transfer_id] => 
    [purchase_id] => 
    [unit_cost] => 3.8900
    [real_unit_cost] => 3.8900
    [net_unit_cost] => 3.89
    [quantity_received] => 1
    [unit_quantity] => 1
    [quantity] => 1
    [quantity_balance] => 1
    [subtotal] => 3.89
    [tax] => 0
    [tax_rate_id] => 5
    [date] => 2019-07-30
)

ERROR - 2019-07-30 17:26:35 --> Could not find the language line " note"
