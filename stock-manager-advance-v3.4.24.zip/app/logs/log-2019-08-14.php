<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-14 11:10:04 --> Severity: Notice --> Undefined property: stdClass::$supplier1price /Users/saleem/Sites/sma/app/controllers/admin/Products.php 2140
ERROR - 2019-08-14 11:10:04 --> Severity: Notice --> Undefined property: stdClass::$supplier1price /Users/saleem/Sites/sma/app/controllers/admin/Products.php 2140
ERROR - 2019-08-14 11:10:04 --> Severity: Notice --> Undefined property: stdClass::$supplier1price /Users/saleem/Sites/sma/app/controllers/admin/Products.php 2140
ERROR - 2019-08-14 11:10:04 --> Severity: Notice --> Undefined property: stdClass::$supplier1price /Users/saleem/Sites/sma/app/controllers/admin/Products.php 2140
ERROR - 2019-08-14 11:10:04 --> Severity: Notice --> Undefined property: stdClass::$supplier1price /Users/saleem/Sites/sma/app/controllers/admin/Products.php 2140
