<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-27 12:47:08 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 30
ERROR - 2019-08-27 12:47:13 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 30
ERROR - 2019-08-27 12:47:42 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 30
ERROR - 2019-08-27 12:55:09 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 30
ERROR - 2019-08-27 13:11:37 --> Severity: Warning --> scandir(/Users/saleem/Sites/sma/themes/default/admin/assets/images/login-bgs/*.jpg): failed to open dir: No such file or directory /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 5
ERROR - 2019-08-27 13:11:37 --> Severity: Warning --> scandir(): (errno 2): No such file or directory /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 5
ERROR - 2019-08-27 13:18:07 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:18:14 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:19:21 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:20:04 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:20:43 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:20:48 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:20:49 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:21:08 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:21:10 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 32
ERROR - 2019-08-27 13:22:04 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:22:05 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:24:23 --> Severity: Notice --> Undefined offset: 5 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:24:24 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:24:25 --> Severity: Notice --> Undefined offset: 4 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:24:27 --> Severity: Notice --> Undefined offset: 4 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:24:33 --> Severity: Notice --> Undefined offset: 5 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:24:49 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:24:54 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:24:56 --> Severity: Notice --> Undefined offset: 5 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:25:02 --> Severity: Notice --> Undefined offset: 4 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:25:05 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:25:06 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:25:09 --> Severity: Notice --> Undefined offset: 5 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:25:16 --> Severity: Notice --> Undefined offset: 5 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:25:18 --> Severity: Notice --> Undefined offset: 6 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 36
ERROR - 2019-08-27 13:26:01 --> Severity: Notice --> Undefined offset: 7 /Users/saleem/Sites/sma/themes/default/admin/views/auth/login.php 37
